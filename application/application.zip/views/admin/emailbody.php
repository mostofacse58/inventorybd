<!DOCTYPE html>
<html>
<body>
<p style="font-size:14px;margin:5px 0px;">Dear Sir,</p>
<p style="font-size:14px;margin:5px 0px;line-height:20px;text-align: justify;"><span style="color:#000">
Good Day!!!
 </span></p>
<p style="font-size:14px;margin:15px 0px 6px;line-height:20px;text-align: justify">
Please see bellow new employee information....</p>
<p style="font-size:14px;margin:5px 0px;line-height:20px;text-align: justify;">
	<span style="color:#000">
Employee Name: <?php echo $info->employee_name; ?><br>
Employee ID No: <?php echo $info->employee_card_id; ?><br>
Joining Date: <?php echo "$info->joining_date"; ?><br>
Designation: <?php echo "$info->post_name"; ?><br>

 </span></p>
<p style="font-size:14px;margin:10px 0px;line-height:20px;">
Thanks by <br>
Ventura IT <br>
</p>
<p style="font-size:14px;margin:5px 0px;line-height:20px;color:#FF4000">
This is auto generated email from Ventura SIM Management Software. No Need to Reply.<br>	

</p>
</body>
</html>