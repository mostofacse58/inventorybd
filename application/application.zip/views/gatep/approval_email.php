<html lang="en"><head><meta charset="UTF-8">
</head>
<body>
<p style="font-size:15px;margin:0px;">
Dear Sir, <br>
Good day. You have one GATEPASS (GATEPASS NO: <?php echo $info->gatepass_no; ?>) from <?php echo $info->department_name ; ?> department for Approval. please check and approved. 
<br>
<a href="<?php echo base_url(); ?>gatep/Approval/viewapproved/<?php echo $info->gatepass_id; ?>">Click for Login</a>
<br><br>
Thanks by <br>
Ventura BD IT <br><br>
This is auto generated email from Ventura Inventory Management Software. No Need to Reply.
</body>
</html>