<html lang="en"><head><meta charset="UTF-8">
</head>
<body>
<p style="font-size:15px;margin:0px;">
Dear sir, <br>
Good day. Please check this attachment for bellow returnable material lists. <br>
<br><br>
Thanks by <br>
Ventura BD IT <br><br>
This is auto generated email from Ventura Gatepass Management Software. No Need to Reply.
</body>
</html>