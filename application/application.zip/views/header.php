<div  style="width:100%;float:left;font-size: 0px;text-align: center;overflow:hidden;margin:0;margin-top: 0px;">
<p style="margin:2px 0px;color: #538FD4;font-size: 25px">
<b> 
 <?php echo  $this->session->userdata('company_name'); ?>
 	
 </b>
</p>
</div>
