<style>
  .form-group.required .control-label:after { 
     content:"*";
     color:red;
  }
  .well-sm {
  border-radius: 3px;
  padding: 7px 25px;
}
</style>

<div class="row">
  <div class="col-md-12">
    <div class="panel panel-success">
   <div class="box box-info">

          </div>
        </div>
   
   </div>
 </div>
 