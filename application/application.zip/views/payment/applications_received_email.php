<html lang="en"><head><meta charset="UTF-8">
</head>
<body>
<p style="font-size:15px;margin:0px;">
Dear Sir, <br>
Good day. You have one Payment Application(PA NO: <?php echo $info->applications_no; ?>) from <?php echo $info->department_name ; ?> department for Receive. please check. <br>
<a href="<?php echo base_url(); ?>">Click for Login</a>
<br><br>
Thanks by <br>
Ventura BD IT <br><br>
This is auto generated email from Ventura Inventory Management Software. No Need to Reply.
</body>
</html>