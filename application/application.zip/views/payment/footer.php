<hr>
<table width="100%" style="vertical-align: bottom; font-family: serif; 
    font-size: 11px; color: #000000; font-weight: bold;">
    <tr>
        <td width="10%"></td>
        <td width="80%" align="center"><?php echo $info->address;  ?></td>
        <td width="10%" style="text-align: right;"><?php echo "{PAGENO}/{nbpg}"; ?></td>
    </tr>
</table>

