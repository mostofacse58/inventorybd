<html lang="en"><head><meta charset="UTF-8">
</head>
<body>
<p style="font-size:15px;margin:0px;">
Dear sir, <br>
Good day. You have one PO/WO (PO/WO NO: <?php echo $info->po_number; ?>) pending for Approval. please check. <br>
<a href="<?php echo base_url(); ?>">Click for Login</a>
<br><br>
Thanks by <br>
Ventura BD IT <br><br>
This is auto generated email from Ventura Inventory Management Software. No Need to Reply.
</body>
</html>